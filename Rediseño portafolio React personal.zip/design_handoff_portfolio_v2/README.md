# Handoff: Portafolio Francisco Del Valle — refactor v2

## Overview
Rediseño completo del portafolio personal (`fdelvalle01/portfoliobase`, React 17 + CRA + react-bootstrap).
Pasa de 5 rutas separadas a **una sola página con secciones ancladas**, agrega **i18n español/inglés**, **tema claro/oscuro**, y secciones nuevas: métricas de impacto, línea de tiempo unificada (experiencia + educación), proyectos con caso de estudio en modal, stack con niveles, testimonios, notas técnicas y contacto con formulario.
Se mantiene la identidad morada oscura actual y elementos que el usuario pidió conservar: partículas de fondo, preloader y el emoji 👋.

## Sobre los archivos de diseño
Los archivos `.dc.html` de este paquete son **referencias de diseño creadas en HTML** — prototipos que muestran el look y el comportamiento buscados, **no código de producción para copiar y pegar**.
La tarea es **recrear estos diseños dentro del proyecto React existente** (`portfoliobase`), usando sus patrones y librerías actuales (CRA, react-bootstrap/MUI si se quiere conservar, o CSS propio). El HTML sirve como especificación visual; la implementación debe ser componentes React.

## Fidelidad
**Alta fidelidad (hifi).** Colores, tipografía, espaciado, estados e interacciones son finales. Recrear pixel-perfect.

---

## Arquitectura propuesta (React)

```
src/
  App.js                  → una sola ruta "/" que renderiza <Site />
  context/I18nContext.js  → { lang, setLang, t }   (es | en)
  context/ThemeContext.js → { theme, setTheme }    (dark | light)  → data-theme en <html>
  data/content.js         → textos es/en, timeline, proyectos, stack
  components/
    Preloader.jsx
    ParticlesCanvas.jsx
    Header.jsx            (nav + toggles ES/EN y tema)
    Hero.jsx
    StatsBand.jsx
    About.jsx
    Timeline.jsx
    Projects.jsx + CaseStudyModal.jsx
    Stack.jsx
    Testimonials.jsx
    Notes.jsx
    Contact.jsx
    Footer.jsx
```

Navegación: `<a href="#seccion">` + `html { scroll-behavior: smooth }`. Se puede eliminar `react-router-dom`, `react-tsparticles` (reemplazado por un canvas propio de ~40 líneas), `typewriter-effect` y `react-pdf`.

---

## Design tokens

Definidos como variables CSS en `:root` y sobreescritos en `[data-theme="light"]`.

| Token | Dark | Light |
| --- | --- | --- |
| `--bg` | `#140f23` | `#f7f4fd` |
| `--bg-2` | `#1b1429` | `#efe9fa` |
| `--surface` | `#1b0c2b` | `#ffffff` |
| `--surface-2` | `#221434` | `#f3eefc` |
| `--text` | `#eae6f2` | `#1b1226` |
| `--muted` | `#a596c0` | `#5d4d76` |
| `--accent` | `#8750f7` | `#6d28d9` |
| `--accent-2` | `#c770f0` | `#8750f7` |
| `--line` | `rgba(200,137,230,0.16)` | `rgba(109,40,217,0.18)` |
| `--band` (banda de métricas) | `#2a1454` | `#2a1454` |
| `--shadow` | `0 4px 24px rgba(9,5,29,0.45)` | `0 4px 24px rgba(90,60,150,0.14)` |

`--accent` y `--accent-2` vienen del sitio actual (`--tj-theme-primary: #8750f7`, `--imp-text-color: #c770f0`).

**Tipografía**
- Titulares: `Sora`, pesos 600/700 (ya usada en los tokens actuales).
- Texto: `Inter`, pesos 400/500/600.
- Escala: h1 hero 60px/1.05 (−0.02em) · h2 sección 40px/1.1 (−0.01em) · h3 tarjeta 19–21px/1.3 · body 16px/1.7 · body-sm 14px/1.65 · meta 13px · kicker 11–12px con `letter-spacing: .14em–.18em`.

**Espaciado** — secciones `padding: 96px 24px`; contenedor `max-width: 1180px; margin: 0 auto`; gaps de grilla 24px (tarjetas), 40–64px (columnas de sección).

**Radios** — 8px general, 6px chips, 12px modal, 16px píldora de estado, 50% puntos del timeline.

**Sombras** — solo `--shadow`; nunca sombras apiladas.

---

## Pantallas / secciones

### 1. Preloader
Overlay `position:fixed; inset:0; z-index:999; background:#0c0513`, centrado: spinner de 44px (`border:2px solid rgba(199,112,240,.25)`, `border-top-color:#c770f0`, `animation: spin .9s linear infinite`) + wordmark `FDV` (Sora, 12px, `letter-spacing:.28em`, `#8a7aa8`).
Se oculta a los **1200 ms** con `transition: opacity .5s` y `pointer-events:none` (mismo timing que el `App.js` actual).

### 2. Partículas de fondo
`<canvas position:fixed; inset:0; z-index:0; pointer-events:none>`. 160 puntos, radio 0.4–1.6px, opacidad 0.15–0.65, deriva **hacia la derecha** a 0.04–0.22 px/frame, reaparecen por la izquierda. Color `rgba(199,112,240,α)` en oscuro y `rgba(109,40,217,α)` en claro. `devicePixelRatio` limitado a 2. Equivale al config de `react-tsparticles` actual (160 partículas, `direction: right`, `size: 1`) sin la dependencia.

### 3. Header (sticky)
`position:sticky; top:0; z-index:40; backdrop-filter:blur(14px); background:color-mix(in srgb, var(--bg) 72%, transparent); border-bottom:1px solid var(--line)`.
Contenido: `max-width:1180px; padding:14px 24px; display:flex; justify-content:space-between; gap:16px; flex-wrap:wrap`.
- Marca: `logo.png` a 22px + “Francisco Del Valle” (Sora 600, 14px), `white-space:nowrap`.
- Links: 8px/12px, `color:var(--muted)`, hover `color:var(--text); background:var(--surface-2)`, `border-radius:8px`, `white-space:nowrap`. Secciones: Sobre mí · Trayectoria · Proyectos · Stack · Notas · Contacto.
- Toggle ES/EN: dos botones en un contenedor con `border:1px solid var(--line); border-radius:8px`; el activo va con fondo `var(--accent)` y texto `#fff`, el inactivo transparente con `var(--muted)`.
- Toggle de tema: botón 34×34, icono Phosphor `sun` (en oscuro) / `moon` (en claro).
- CTA “Hablemos”: **outline** — `padding:8px 16px; border:1px solid var(--accent); color:var(--accent-2)`, hover `background:rgba(135,80,247,.12)`.

### 4. Hero (`#inicio`)
Grid `repeat(auto-fit, minmax(340px,1fr))`, gap 56px, `padding:104px 24px 88px`.
Izquierda:
- Píldora de estado: `inline-flex; flex-wrap:wrap; padding:7px 14px; border:1px solid var(--line); border-radius:16px; font-size:12px` con punto verde 6px (`#4ade80`, `box-shadow:0 0 8px #4ade80`). Texto: “Santiago, Chile · disponible para proyectos remotos” / “Santiago, Chile · open to remote work”.
- “Hola 👋🏻” / “Hi there 👋🏻” en 19px `var(--muted)`; el emoji conserva la animación `wave` del CSS actual (2.1s, `transform-origin:70% 70%`).
- Nombre: 60px/1.05, 700. “Del Valle” con `background:linear-gradient(to right, var(--accent) 0%, var(--accent-2) 60%, var(--text) 100%)` + `background-clip:text`.
- Bajada 19px `var(--muted)`, máx 560px: “Full Stack Developer. Construyo software para mercados bursátiles: plataformas de trading, gestión de entidades y sistemas que operan en producción todos los días.”
- Chips de stack (React, Node.js, Java, SQL Server, LoopBack, PostgreSQL): 12px, `background:var(--surface-2); border:1px solid var(--line); border-radius:8px`.
- CTAs: “Ver proyectos” (outline accent) · “Ver CV” (outline `var(--line)`, icono `ph/read-cv-logo`) · iconos 42×42 de GitHub y LinkedIn.
Derecha: ilustración (`avatar.svg`) sobre un glow `radial-gradient(circle, rgba(135,80,247,.28) 0%, transparent 70%)` de 340px con `filter:blur(20px)`.

> Nota: `home-main.svg` del repo no se pudo traer (imagen raster incrustada); en el prototipo se usa `avatar.svg`. En la implementación real conviene usar el SVG original del repo o una ilustración/foto nueva.

### 5. Banda de métricas
Full-bleed, `background:var(--band) (#2a1454)`, bordes superior/inferior `rgba(255,255,255,.06)`, `padding:44px 24px`, grid `repeat(auto-fit, minmax(190px,1fr))`, gap 32px.
Cifra: Sora 38px/1 700 `#fff`; etiqueta: 13px `rgba(255,255,255,.62)`.
Valores: **6+** años en infraestructura bursátil · **2** mercados (Chile y Rep. Dominicana) · **3** roles en Bolsa de Santiago / nuam · **24/7** sistemas en producción.
(Única superficie saturada de la página — no repetir el color en bloques grandes.)

### 6. Sobre mí (`#sobre-mi`)
Grid `repeat(auto-fit, minmax(320px,1fr))`, gap 64px. Kicker “01 — SOBRE MÍ”. Título “Backend serio, frontend cuidado.” (40px, máx 14ch).
Dos párrafos de 16px/1.75 `var(--muted)` (formación INACAP + diplomado UC; trabajo desde 2020 en Bolsa de Santiago / nuam; intereses).
Dos tarjetas pequeñas: “Actualmente / Full Stack Developer · nuam exchange” y “Idiomas / Español (nativo) · Inglés A2+” (`padding:16px 18px; border:1px solid var(--line); background:var(--surface-2)`).
Derecha: `about.png`.

### 7. Trayectoria (`#trayectoria`)
Fondo `var(--bg-2)`, kicker “02”. Timeline vertical: contenedor `padding-left:34px; border-left:1px solid var(--line)`, tarjetas separadas 14px.
Cada tarjeta: `padding:22px 26px; border:1px solid var(--line); border-radius:8px; background:var(--surface); box-shadow:var(--shadow)`, hover `border-color:var(--accent)`.
Punto: `position:absolute; left:-41px; top:26px; 13px; border-radius:50%`, `background:var(--accent)` para TRABAJO y `var(--accent-2)` para FORMACIÓN, con `box-shadow:0 0 0 4px var(--bg-2)`.
Fila superior: rango de años (Sora 13px 700 `var(--accent-2)`) + etiqueta TRABAJO/FORMACIÓN (11px `letter-spacing:.14em` `var(--muted)`). Luego título 21px 600 y lugar 14px `var(--muted)`.
Entradas (orden inverso, datos de `Experience.jsx`): 2022–Actualidad Full Stack Developer · 2022–2023 Diplomado Apps Móviles (PUC) · 2021–2022 Inglés A2 · 2020–2022 Programador · 2020 Práctica profesional · 2016–2020 Ingeniería en Informática (INACAP).

### 8. Proyectos (`#proyectos`)
Grid `repeat(auto-fit, minmax(280px,1fr))`, gap 24px, 3 tarjetas.
Tarjeta: `border:1px solid var(--line); border-radius:8px; background:var(--surface); overflow:hidden; cursor:pointer`, hover `transform:translateY(-4px); border-color:var(--accent)` con `transition: transform .25s ease, border-color .25s ease`.
Imagen `aspect-ratio:16/10; object-fit:cover; opacity:.88`; cuerpo `padding:22px 22px 24px; gap:12px`; kicker 11px `var(--accent-2)`; título 19px 600; descripción 14px/1.65 `var(--muted)`; chips de stack 11px; enlace “Ver caso →” 13px 600 `var(--accent-2)`.
Proyectos y textos: los tres de `Projects.js` (BVRD, gestión de usuarios Sebra HT, e-commerce Lácteos Del Valle).

**Modal de caso de estudio** — reemplaza al `ProjectModal.jsx` actual (que hoy muestra Lorem ipsum).
Backdrop `rgba(8,4,18,.72)` + `backdrop-filter:blur(6px)`, `padding:40px`, cierra al hacer clic fuera y con el botón ✕ (36px, `ph/x`).
Panel: `max-width:820px; max-height:86vh; overflow-y:auto; border-radius:12px; background:var(--surface); border:1px solid var(--line); box-shadow:0 24px 60px rgba(0,0,0,.5)`, entrada `fadeUp .3s ease` (opacity 0→1, translateY 14px→0).
Contenido: imagen 16/8 · kicker · título 29px · dos columnas **CONTEXTO** y **MI ROL** (14px/1.7 `var(--muted)`) · bloque **RESULTADO** destacado (`background:var(--surface-2)`, borde, 15px/1.7) · chips de STACK · botón outline “Ver el producto” (solo si hay link).
Los textos de los 3 casos (es/en) están en el array `CASES` del archivo de diseño.

### 9. Stack (`#stack`)
Fondo `var(--bg-2)`. Tres columnas (`repeat(auto-fit, minmax(260px,1fr))`, gap 40px): FRONTEND · BACKEND · DATOS Y HERRAMIENTAS.
Cada fila: icono 18px + nombre (14px 600) + nivel (11px `var(--muted)`: A diario / Frecuente / Ocasional) y una barra `height:4px; border-radius:2px; background:var(--surface-2)` con relleno `linear-gradient(to right, var(--accent), var(--accent-2))`.
Porcentajes: React 92 · JavaScript 94 · HTML/CSS 88 · MUI 72 · Node.js 88 · Java 78 · LoopBack 74 · Python 52 · SQL Server 85 · PostgreSQL 70 · Git 90 · Firebase 68 · Linux 55.

### 10. Testimonios
Dos `<figure>` (`repeat(auto-fit, minmax(300px,1fr))`, gap 24px): icono `ph/quotes-fill` 26px `var(--accent)`, cita 17px/1.65, autor 13px `var(--muted)`.
**Contenido pendiente**: hoy hay placeholders; reemplazar con recomendaciones reales de LinkedIn.

### 11. Notas técnicas (`#notas`)
Fondo `var(--bg-2)`. Encabezado con badge “Próximamente”. Tres tarjetas-enlace (`padding:26px 26px 30px`, hover `border-color:var(--accent)`): meta (Borrador · X min), título 18px, resumen 14px.

### 12. Contacto (`#contacto`)
Grid `repeat(auto-fit, minmax(320px,1fr))`, gap 64px.
Izquierda: kicker “07”, título “¿Trabajamos juntos?”, copy (respuesta en <48h) y tres filas de contacto (email, LinkedIn, GitHub) con icono Phosphor y `border:1px solid var(--line)`, hover `border-color:var(--accent); background:var(--surface-2)`.
Derecha: formulario en tarjeta (`padding:34px; border:1px solid var(--line); background:var(--surface); box-shadow:var(--shadow)`).
Campos: Nombre + Email en `grid-template-columns:repeat(2,minmax(0,1fr))`; Empresa (opcional); Mensaje (`textarea rows=5`, `resize:vertical`). Inputs: `min-width:0; width:100%; padding:12px 14px; border:1px solid var(--line); border-radius:8px; background:var(--bg-2); color:var(--text); font-size:14px`.
Botón submit outline accent. Al enviar se muestra confirmación verde (`#4ade80`).
**Backend pendiente**: conectar a Formspree, EmailJS o una función serverless; hoy el submit solo cambia estado local.

### 13. Footer
`border-top:1px solid var(--line); background:var(--bg-2); padding:32px 24px`, flex con copyright 13px `var(--muted)` a la izquierda y dos iconos 34×34 a la derecha.

---

## Interacciones y comportamiento
- **Idioma**: estado `lang` ('es' | 'en'). Inicial: `localStorage['fdv-lang']` → si no existe, `navigator.language.startsWith('es') ? 'es' : 'en'`. Persistir en cada cambio. En el prototipo se resuelve con `data-lang` en la raíz y dos `<span data-l="es|en">`; en React usar un diccionario `t(key)`.
- **Tema**: estado `theme` ('dark' | 'light'). Inicial: `localStorage['fdv-theme']` → si no, `matchMedia('(prefers-color-scheme: light)')`. Aplicar como `data-theme` en `<html>` y persistir.
- **Modal**: estado `openProject` (índice | null); `Escape` y clic en backdrop cierran; bloquear scroll del body mientras está abierto.
- **Hover**: tarjetas de proyecto elevan 4px; tarjetas de timeline y notas cambian el borde a `var(--accent)`; links de nav tintan el fondo.
- **Foco**: `:focus-visible { outline:2px solid var(--accent); outline-offset:2px }` en todos los interactivos. Nunca el azul por defecto.
- **Animaciones**: `wave` 2.1s infinita en el emoji; `spin` .9s en el preloader; `fadeUp` .3s al abrir el modal; `scroll-behavior:smooth` para las anclas.
- **Responsive**: todas las grillas usan `auto-fit + minmax`, así que colapsan solas; el nav envuelve con `flex-wrap`. Revisar el hero a <420px (bajar el nombre a ~44px).

## Estado
`lang`, `theme`, `loaded` (preloader), `openProject`, `sent` (formulario). Sin data fetching: todo el contenido es estático en `data/content.js`.

## Assets
Copiados desde el repo a `src/Assets/`: `logo.png`, `avatar.svg`, `about.png`, `home-bg.jpg`, `Projects/sebraht.png`, `Projects/sebraht_siadus.png`, `Projects/lacteos_mant.png`.
`home-main.svg` no se pudo copiar íntegro (raster incrustado) — usar el del repo.
`Francisco_DelValleCV.pdf` no está en el repo; el CTA “Ver CV” apunta hoy a LinkedIn: reemplazar por el PDF cuando exista.
**Iconos**: Phosphor (`ph/*`) para la interfaz y Simple Icons / Devicons para los logos de tecnologías. En el prototipo se cargan como `<img>` desde `api.iconify.design`; en React usar `phosphor-react` (o `@phosphor-icons/react`) y `react-icons/si`.

## Archivos
- `Portafolio v2.dc.html` — el diseño nuevo, completo, con i18n y temas funcionando.
- `Portafolio Actual (recreación).dc.html` — recreación del sitio actual (referencia del punto de partida).
